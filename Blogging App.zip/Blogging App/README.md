# NEWS APP
This is a NEWS App built using React Native. You can read the trending NEWS or if you want you can read them category wise. You are requested to please watch the tutorial and generate an API_KEY for yourself in order to run the app.

### Categories
- Entertainment
- Business 
- Health
- Politics
- Technology
- Sports

### Tutorial 
You can find the step by step tutorial to this app [here](https://sgcodes.tech/youtube)

### Screens

| ![](assets/Screenshots(1).jpeg) | ![](assets/Screenshots(2).jpeg) | ![](assets/Screenshots(3).jpeg) |
| :-------------: | :-------------: | :-------------:  |