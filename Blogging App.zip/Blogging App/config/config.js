import { API_KEY } from '@env';

export default { API_KEY } ;